from django.core.management.base import BaseCommand
from django.utils import timezone
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.conf import settings
from training.models import ClassSchedule, Enrollment
from datetime import timedelta

class Command(BaseCommand):
    help = 'Send email reminders for upcoming classes (6 hours and 30 minutes before)'

    def handle(self, *args, **kwargs):
        now = timezone.now()
        self.stdout.write(f"Checking for classes at {now}")

        # --- 6 HOUR REMINDER ---
        # Trigger ONLY if class is <= 6 hours away (but not too late, e.g. > 1 hr)
        start_range_6h = now + timedelta(hours=6)
        
        # We look for classes starting anytime between NOW and 6 hours from now
        # But we rely on the 'reminder_6hr_sent' flag to ensure we do it only once.
        # To avoid sending it for classes startin in 30 mins (which are also < 6h),
        # we can set a lower bound, or just let it happen (user gets 2 emails).
        # Better: Strict window [Now + 1h, Now + 6h]
        
        classes_6hr = ClassSchedule.objects.filter(
            start_time__gte=now + timedelta(hours=1), # Don't send 6h reminder if it's already 30 mins away
            start_time__lte=start_range_6h,
            reminder_6hr_sent=False
        )

        for schedule in classes_6hr:
            self.send_notifications(schedule, '6hr')
            schedule.reminder_6hr_sent = True
            schedule.save()
            self.stdout.write(self.style.SUCCESS(f"Sent 6hr reminders for {schedule}"))

        # --- 30 MINUTE REMINDER ---
        # Trigger ONLY if class is <= 30 minutes away
        start_range_30m = now + timedelta(minutes=30)

        classes_30min = ClassSchedule.objects.filter(
            start_time__gte=now,
            start_time__lte=start_range_30m,
            reminder_30min_sent=False
        )

        for schedule in classes_30min:
            self.send_notifications(schedule, '30min')
            schedule.reminder_30min_sent = True
            schedule.save()
            self.stdout.write(self.style.SUCCESS(f"Sent 30min reminders for {schedule}"))

    def send_notifications(self, schedule, type_code):
        batch = schedule.batch
        self.stdout.write(f"Processing batch: {batch}")
        
        # Find active enrollments
        active_enrollments = Enrollment.objects.filter(
            batch=batch,
            expires_at__gte=timezone.now()
        )
        self.stdout.write(f"Found {active_enrollments.count()} active enrollments.")
        
        # Get unique users
        users = set(e.user for e in active_enrollments if e.user.email)
        self.stdout.write(f"Found {len(users)} unique users with emails.")
        
        if not users:
            self.stdout.write(f"No active students found for {schedule}")
            return

        template_name = 'training/emails/class_reminder_6hr.html' if type_code == '6hr' else 'training/emails/class_reminder_30min.html'
        
        # Calculate time remaining string
        now = timezone.now()
        diff = schedule.start_time - now
        minutes_left = int(diff.total_seconds() / 60)
        
        if minutes_left <= 0:
            time_str = "now"
            subject = f"Class Starting Now: {schedule.topic}"
        elif type_code == '6hr':
             time_str = "6 hours"
             subject = f"Reminder: Class in 6 Hours - {schedule.topic}"
        else:
             time_str = f"{minutes_left} minutes"
             subject = f"Class Starting in {minutes_left} Mins: {schedule.topic}"

        for user in users:
            self.stdout.write(f"Attempting to send to: '{user.email}' (User: {user.username})")
            try:
                html_message = render_to_string(template_name, {
                    'user': user,
                    'class_schedule': schedule,
                    'time_str': time_str,
                })
                
                plain_message = f"""
Hello {user.first_name},

Your class is starting in about {time_str}.

Topic: {schedule.topic}
Start Time: {schedule.start_time.strftime('%I:%M %p')}

Link: {schedule.meeting_link if schedule.meeting_link else 'Check dashboard'}

See you there!
"""
                
                sent_count = send_mail(
                    subject,
                    plain_message,
                    settings.EMAIL_HOST_USER, # From email
                    [user.email], # To email
                    html_message=html_message,
                    fail_silently=False
                )
                self.stdout.write(self.style.SUCCESS(f"Send_mail returned: {sent_count}"))
                
            except Exception as e:
                self.stderr.write(self.style.ERROR(f"Failed to send email to {user.email}: {e}"))
